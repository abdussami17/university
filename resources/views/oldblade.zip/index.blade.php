@extends('layout.app')

@section('title', 'University')

@section('content')
<section class="main-section">
            <video autoplay loop playsinline muted >
                <source src="{{'Images/'.$data->mainbanner}}" type="video/mp4">
           
               
                Your browser does not support the video tag.
              </video>
        </section>

        <section class="heading-container">
            <h2 class="professional-heading main-heading">{{$data->firstsection_title}}</h2>
          </section>
          <style>
   /* Container for heading */
.heading-container {
  display: flex;
  justify-content: center; /* Center horizontally */
  align-items: center; /* Center vertically */
  height: 150px; /* Adjust the height */
  background-color: #f5f5f5; /* Light background for contrast */
}

/* Professional heading styling */
.professional-heading {
  font-size: 32px; /* Adjust the font size */
  font-weight: bolder; /* Make it even bolder */
  color: #212121; /* Professional dark gray color */
  text-transform: none; /* Remove uppercase transformation */
  letter-spacing: 2px; /* Add spacing between letters */
  text-align: center; /* Center align the text */
  position: relative; /* Enable pseudo-element positioning */
  margin: 0; /* Remove default margins */
}

/* Decorative underline */




</style>
<section class="image-slider-container">
            <div class="cards-container">
                <div class="card">
                    <img src="{{'Images/'.$data->firstsection_box1_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->firstsection_box1_title}}</h2>
                        <p>{!!$data->firstsection_box1_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->firstsection_box2_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->firstsection_box2_title}}</h2>
                        <p>{!!$data->firstsection_box2_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->firstsection_box3_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->firstsection_box3_title}}</h2>
                        <p>{!!$data->firstsection_box3_description!!}</p>
                    </div>
                </div>
            </div>
        </section>
        
        <style>
            /* General styles */
            .image-slider-container {
                padding: 20px;
                background-color: #f9f9f9;
            }
        
            /* Cards container */
            .cards-container {
                display: flex !important;
              justify-content: space-between !important;
                flex-wrap: wrap !important; /* Responsive behavior */
            }
        
  
        
            /* Content below the image */
            .card-content {
                padding: 20px;
                background-color: #fff; /* Background for the content */
                border-radius: 0 0 15px 15px; /* Rounded corners at the bottom */
            }
        
            .card-content h2 {
                font-size: 20px;
                margin: 10px 0;
            }
        
            .card-content p {
                font-size: 16px;
            }
        
            /* Hover effect removal */
            .card:hover {
                transform: none; /* Remove the lift effect */
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Maintain default shadow */
            }
        
            /* No overlay effect */
            .card-overlay {
                display: none; /* Hide the overlay */
            }
        </style>
                <section class="heading-container">
            <h2 class="professional-heading main-heading">{{$data->secondsection_title}}</h2>
          </section>
          <section class="image-slider-container">
          <div class="cards-container">
                <div class="card">
                    <img src="{{'Images/'.$data->secondsection_box1_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->secondsection_box1_title}}</h2>
                        <p>{!!$data->secondsection_box1_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->secondsection_box2_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->secondsection_box2_title}}</h2>
                        <p>{!!$data->secondsection_box2_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->secondsection_box3_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->secondsection_box3_title}}</h2>
                        <p>{!!$data->secondsection_box3_description!!}</p>
                    </div>
                </div>
            </div>
        </section>
        
        <style>
            /* General styles */
            .image-slider-container {
                padding: 20px;
                background-color: #f9f9f9;
            }
        
        
        </style>
                <section class="heading-container">
            <h2 class="professional-heading main-heading">{{$data->thirdsection_title}}</h2>
          </section>
          <section class="image-slider-container">
          <div class="cards-container">
                <div class="card">
                    <img src="{{'Images/'.$data->thirdsection_box1_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->thirdsection_box1_title}}</h2>
                        <p>{!!$data->thirdsection_box1_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->thirdsection_box2_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->thirdsection_box2_title}}</h2>
                        <p>{!!$data->thirdsection_box2_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->thirdsection_box3_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->thirdsection_box3_title}}</h2>
                        <p>{!!$data->thirdsection_box3_description!!}</p>
                    </div>
                </div>
            </div>
        </section>
        
        <style>
            /* General styles */
            .image-slider-container {
                padding: 20px;
                background-color: #f9f9f9;
            }
        
           
        </style>    
<br>
<section class="heading-container">
    <h2 class="professional-heading main-heading">Personal Development through Workshops and 
        Events</h2>
  </section>
  <br>
<!-- Bootstrap CDN -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<section class="outter hero-video">
    <section class="video-container">
        <video src="./assets/Workshop Render0001-0266.mp4" autoplay loop playsinline muted></video>

        <!-- Bootstrap Container for Centering -->
        <div class="container" style="padding-top: 25px;">
            <div class="row justify-content-center">
                <div class="col-6 col-md-6 col-lg-6 mb-4"> <!-- 2 columns per row on mobile and desktop -->
                    <div class="box">
                        <h5 class="professional-heading1">Career Development</h5>
                        <p>Boost your career prospects with our practical workshops. Learn how to write compelling applications, present yourself effectively in interviews, and network efficiently. Benefit from the experiences of successful professionals and prepare optimally for your career start.</p>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-6 mb-4"> <!-- 2 columns per row on mobile and desktop -->
                    <div class="box">
                        <h5 class="professional-heading1">Mindset and Stress Management</h5>
                        <p>Master the challenges of your studies with our workshops on resilience, relaxation techniques, and time management. Learn how to maintain balance even in stressful exam periods and care for your mental health.</p>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-6 mb-4"> <!-- 2 columns per row on mobile and desktop -->
                    <div class="box">
                        <h5 class="professional-heading1">Financial Education</h5>
                        <p>Become a finance pro with our training on budgeting, tax optimisation, and dealing with funding. Understand the basics of financial independence and lay the foundation for a secure financial future during your studies.</p>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-6 mb-4"> <!-- 2 columns per row on mobile and desktop -->
                    <div class="box">
                        <h5 class="professional-heading1">Networking Events</h5>
                        <p>Make valuable contacts at our exclusive meetings with industry experts, alumni, and potential employers. Expand your professional network and discover exciting career opportunities in a relaxed atmosphere.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</section>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
/* Hero Video Section */
.outter.hero-video {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.video-container {
    height: 550px;
    width: 100%;
    position: relative;
    overflow: hidden;
}

video {
    object-fit: cover;
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
}

/* Boxes Section */
.box {
    background-color: rgba(255, 255, 255, 0.7);  /* Semi-transparent background */
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    color: #333;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    height: 220px; /* Fixed height for uniform box height */
    display: flex;
    flex-direction: column;
    justify-content: space-between; /* Ensures text remains spaced evenly */
}

h3 {
    margin-bottom: 10px;
    color: #333;
}

p {
    font-size: 14px;
    color: #555;
    flex-grow: 1; /* Allow text to take available space */
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .box {
        padding: 15px;
        height: auto; /* Adjust height based on content */
    }
}

/* Extra small screen responsiveness (max-width: 480px) */
@media (max-width: 480px) {
    .box {
        padding: 11px;
        height: auto; /* Auto height to adjust based on content */
    }

    .video-container {
        height: 700px; /* Increased the video height for small screens */
    }

    .button {
        font-size: 14px; /* Adjust button font size for small screens */
        padding: 12px 24px;
    }

    h3 {
        font-size: 16px;
    }

    p {
        font-size: 12px;
    }
}
</style>


<br>
        <section class="heading-container">
            <h2 class="professional-heading main-heading">{{$data->lastsection_title}}</h2>
          </section>
<style>
   /* Container for heading */
.heading-container {
  display: flex;
  justify-content: center; /* Center horizontally */
  align-items: center; /* Center vertically */
  height: 150px; /* Adjust the height */
  background-color: #f5f5f5; /* Light background for contrast */
}

/* Professional heading styling */
.professional-heading {
  font-size: 32px; /* Adjust the font size */
  font-weight: 900; /* Maximum boldness (Roboto's boldest weight) */
  font-family: 'Roboto', sans-serif; /* Roboto font family */
  color: #212121; /* Professional dark gray color */
  text-transform: none; /* Remove uppercase transformation */
  letter-spacing: 2px; /* Add spacing between letters */
  text-align: center; /* Center align the text */
  position: relative; /* Enable pseudo-element positioning */
  margin: 0; /* Remove default margins */
}


/* Decorative underline */



.professional-heading1 {
 
  font-family: 'Roboto', sans-serif; /* Roboto font family */

  text-align: center; /* Center align the text */
  position: relative; /* Enable pseudo-element positioning */
  margin: 0; /* Remove default margins */
}


/* Decorative underline */



</style>
<section class="image-slider-container">
<div class="cards-container">
                <div class="card">
                    <img src="{{'Images/'.$data->lastsection_box1_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->lastsection_box1_title}}</h2>
                        <p>{!!$data->lastsection_box1_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->lastsection_box2_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->lastsection_box2_title}}</h2>
                        <p>{!!$data->lastsection_box2_description!!}</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{'Images/'.$data->lastsection_box3_image}}" alt="Movie 1">
                    <div class="card-content">
                        <h2 class="professional-heading">{{$data->lastsection_box3_title}}</h2>
                        <p>{!!$data->lastsection_box3_description!!}</p>
                    </div>
                </div>
            </div>
        </section>
        
        <style>
            /* General styles */
            .image-slider-container {
                padding: 20px;
                background-color: #f9f9f9;
            }
        
          
        </style>
        

        <section class="container-fluid section-8">
    <div class="container">
        <h2 class="text-center text-white wow animate__animated animate__fadeInUp">Your Path to Success - Simple, Flexible, Transparent</h2>
        <div class="middle-box">
            <table>
                <thead>
                    <th>Simplicity</th>
                    <th>Flexibility</th>
                    <th>Transparency</th>

                </thead>
                <tbody>
                    <tr>
                        <td>Central dashboard for all information 
                            and functions</td>
                            <td>Offers and workshops tailored to your 
                                schedule</td>
                                <td>
                                    Clear presentation of all terms and 
costs
                                </td>
                    </tr>
                    <tr>
                        <td>Intuitive navigation through all 
                            platform areas
                            </td>
                            <td>24/7 access to resources and support</td>
                            <td>Detailed explanations of all offers and 
                                services</td>
                    </tr>
                    <tr>
                        <td>
                            Quick access to personalised <br>
recommendations
                        </td>
                        <td>
                            Mobile optimisation for learning and 
planning on the go
                        </td>
                        <td>
                            Regular updates on changes and new 
features
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</section>
@endsection
