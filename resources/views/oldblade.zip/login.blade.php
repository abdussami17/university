<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/account/fonts/icomoon/style.css">
    <link rel="stylesheet" href="assets/account/css/owl.carousel.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/account/css/bootstrap.min.css">
    <!-- Style -->
    <link rel="stylesheet" href="assets/account/css/style.css">
    <link rel="icon" type="image/x-icon" href="assets/account/images/logo23.png">
    <title>University</title>
  </head>
  <body>
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
      }
.alert{
  border-radius: .375rem;
  padding: 1rem;
  margin-bottom: 1rem;
  border: 1px solid #a3cfbb;
  margin-top: 1rem;
  font-size: 13px;
  font-weight: 500;
}
.alert.alert-success{
  background-color: #d1e7dd;
  color: #0a3622;
}
.alert.alert-danger{
  background-color: #f8d7da;
  border-color: #f1aeb5;
  color: #58151c;
}
      body {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f5f5f5;
        padding: 20px;
      }

      .login-card {
        background: white;
        border-radius: 20px;
        padding: 3rem 2rem;
        width: 100%;
        max-width: 420px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
      }

      .brand {
        text-align: center;
        margin-bottom: 2rem;
      }

      .brand-logo {
        width: 50px;
        height: 50px;
        background: #000;
        border-radius: 50%;
        margin: 0 auto 1rem;
      }

      .brand h1 {
        font-size: 1.75rem;
        color: #1a1a1a;
        margin-bottom: 0.5rem;
      }

      .brand p {
        color: #666;
        font-size: 0.95rem;
      }

      .form-group {
        margin-bottom: 1.5rem;
        position: relative;
      }

      .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: #333;
        font-size: 0.9rem;
        font-weight: 500;
      }

      .form-group input {
        width: 100%;
        padding: 0.8rem 1rem;
        border: 2px solid #e1e1e1;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
      }

      .form-group input:focus {
        outline: none;
        border-color: #000;
        box-shadow: 0 0 0 4px rgba(0, 0, 0, 0.1);
      }

      .remember-forgot {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
      }

      .remember-me {
        display: flex;
        align-items: center;
        gap: 0.5rem;
      }

      .remember-me input[type="checkbox"] {
        width: 16px;
        height: 16px;
        border-radius: 4px;
      }

      .remember-me label {
        color: #666;
        font-size: 0.9rem;
      }

      .forgot-password {
        color: #000;
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 500;
      }

      .login-btn {
        width: 100%;
        padding: 1rem;
        background: #000;
        color: white;
        border: none;
        border-radius: 12px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .login-btn:hover {
        background: #333;
        transform: translateY(-2px);
      }

      .login-btn:active {
        transform: translateY(0);
      }

      .social-login {
        margin-top: 2rem;
        text-align: center;
      }

      .social-login p {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 1rem;
        position: relative;
      }

      .social-login p::before,
      .social-login p::after {
        content: "";
        position: absolute;
        top: 50%;
        width: 45%;
        height: 1px;
        background: #e1e1e1;
      }

      .social-login p::before {
        left: 0;
      }

      .social-login p::after {
        right: 0;
      }

      .social-buttons {
        display: flex;
        gap: 1rem;
        justify-content: center;
      }

      .social-btn {
        width: 50px;
        height: 50px;
        border: 2px solid #e1e1e1;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .social-btn:hover {
        border-color: #000;
        background: #f5f5f5;
      }

      .signup-link {
        text-align: center;
        margin-top: 1.5rem;
      }

      .signup-link a {
        color: #000;
        text-decoration: none;
        font-weight: 600;
      }

      .signup-link a:hover {
        text-decoration: underline;
      }

      .error {
        color: #dc3545;
        font-size: 0.85rem;
        margin-top: 0.5rem;
        display: block;
      }

      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20%, 60% { transform: translateX(-5px); }
        40%, 80% { transform: translateX(5px); }
      }

      .shake {
        animation: shake 0.5s ease;
      }

      /* Style for back button */
      .back-btn {
        position: absolute;
        top: 20px;
        left: 20px;
        font-size: 1.5rem;
        color: #333;
        cursor: pointer;
        text-decoration: none;
        transition: color 0.3s;
      }

      .back-btn:hover {
        color: #000;
      }
    </style>

    <!-- Back Button -->
    <a href="/" class="back-btn">
      <i class="fas fa-arrow-left"></i> <!-- Font Awesome back arrow icon -->
    </a>

    <div class="login-card">
        <div class="brand">
          <img src="{{asset('assets/Images/website.png')}}" alt="" width="60%">
            <h1>Welcome back</h1>
            <p>Enter your credentials to access your account</p>
        </div>
@if(Session::has('success'))
<div class="alert alert-success">{{Session::get('success')}}</div>
@endif
@if(Session::has('error'))
<div class="alert alert-danger">{{Session::get('error')}}</div>
@endif
        <form id="loginForm"  action="{{route('account.authenticate')}}" method="post">
          @csrf
            <div class="form-group">
                <label for="email">Email</label>
                <input 
                    type="text" 
                    id="email" 
                    name="email"  value="{{old('email')}}"
class=" @error('email') is-invalid  @enderror"
                    placeholder="name@company.com"
                    autocomplete="email"
                >
                @error('email')
                <div class="error" id="emailError">{{$message}}</div>
                @enderror
               
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class=" @error('password') is-invalid  @enderror"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                >
                @error('password')
                <div class="error" id="passwordError">{{$message}}</div>
                @enderror
            </div>

            <div class="remember-forgot">
                <div class="remember-me">
                    <input type="checkbox" id="remember">
                    <label for="remember">Remember me</label>
                </div>
                <a href="#" class="forgot-password">Forgot password?</a>
            </div>

            <button type="submit" class="login-btn" id="loginButton">
                Sign in
            </button>
        </form>

        <div class="social-login">
            <p>Or continue with</p>
            <div class="social-buttons">
              <a href="{{ route('register.google') }}">
              <div class="social-btn">
                  <i class="fas fa-envelope"></i> <!-- Gmail Icon -->
              </div>
              </a>
              <div class="social-btn">
                  <i class="fab fa-apple"></i> <!-- Apple Icon -->
              </div>
              <a href="{{ route('register.facebook') }}">
              <div class="social-btn">
                  <i class="fab fa-facebook-f"></i> <!-- Facebook Icon -->
              </div>
            </a>
          </div>
        </div>

        <div class="signup-link">
            <p>Don't have an account? <a href="{{route('account.register')}}">Sign up</a></p>
        </div>
    </div>
</body>
</html>
