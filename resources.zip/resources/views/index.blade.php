@extends('layout.app')

@section('title', trans('general.University'))

@section('content')

{{-- ══════════════════════════════════════════════════════
     ORIGINAL PHP HELPER + INLINE OVERRIDES
══════════════════════════════════════════════════════ --}}
@php
if (!function_exists('get_setting')) {
    function get_setting($key, $default = null, $lang = false)
    {
        $settings = Cache::remember('Setting', 2, function () {
            return App\Models\Setting::all();
        });

        if ($lang == false) {
            $setting = $settings->where('type', $key)->first();
        } else {
            $setting = $settings->where('type', $key)->where('lang', $lang)->first();
            $setting = !$setting ? $settings->where('type', $key)->first() : $setting;
        }
        return $setting == null ? $default : $setting->value;
    }
}
@endphp

<style>
    /* ── Hide things that belong to other layouts ── */
    .others-footer { display: none; }
    .home-none     { display: none !important; }

    /* ── Override card img width from parent layout ── */
    .card img { width: 100% !important; }

    /* ══════════════════════════════════════════════════
       HERO SECTION
    ══════════════════════════════════════════════════ */
    .pai-hero {
        text-align: center;
        padding: var(--sp-16) var(--sp-6) var(--sp-12);
        background: var(--color-white);
        border-bottom: 1px solid var(--color-border);
        position: relative;
        overflow: hidden;
    }
    .pai-hero::before {
        content: '';
        position: absolute;
        inset: 0;
        background: repeating-linear-gradient(
            0deg,
            transparent,
            transparent 39px,
            var(--color-border) 39px,
            var(--color-border) 40px
        );
        opacity: 0.35;
        pointer-events: none;
    }
    .pai-hero__eyebrow {
        display: inline-block;
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        color: var(--color-primary);
        border: 1.5px solid var(--color-primary);
        padding: var(--sp-1) var(--sp-4);
        margin-bottom: var(--sp-6);
        position: relative;
    }
    .pai-hero__title {
        font-family: var(--font-heading);
        font-size: clamp(2.4rem, 6vw, 5rem);
        font-weight: 900;
        color: var(--color-dark);
        text-transform: uppercase;
        letter-spacing: -0.02em;
        line-height: 1;
        margin-bottom: var(--sp-6);
        position: relative;
    }
    .pai-hero__subtitle {
        font-size: var(--fs-md);
        color: var(--color-muted);
        line-height: 1.7;
        max-width: 560px;
        margin: 0 auto var(--sp-8);
        position: relative;
    }
    .pai-hero__cta-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: var(--sp-4);
        flex-wrap: wrap;
        margin-bottom: var(--sp-10);
        position: relative;
    }
    .pai-hero__btn-primary {
        display: inline-flex;
        align-items: center;
        gap: var(--sp-2);
        padding: var(--sp-4) var(--sp-8);
        background: var(--color-primary);
        color: var(--color-white);
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        border: 2px solid var(--color-primary);
        border-radius: var(--radius-sm);
        transition: background var(--transition), transform var(--transition);
        text-decoration: none;
    }
    .pai-hero__btn-primary:hover {
        background: var(--color-primary-dark);
        border-color: var(--color-primary-dark);
        transform: translateY(-2px);
        color: var(--color-white);
        text-decoration: none;
    }
    .pai-hero__btn-outline {
        display: inline-flex;
        align-items: center;
        gap: var(--sp-2);
        padding: var(--sp-4) var(--sp-8);
        background: transparent;
        color: var(--color-dark);
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        border: 1.5px solid var(--color-dark);
        border-radius: var(--radius-sm);
        transition: background var(--transition), color var(--transition);
        text-decoration: none;
    }
    .pai-hero__btn-outline:hover {
        background: var(--color-dark);
        color: var(--color-white);
        text-decoration: none;
    }
    /* Media inside hero */
    .pai-hero__media {
        position: relative;
        max-width: 900px;
        margin: 0 auto;
        border: 1px solid var(--color-border);
    }
    .pai-hero__media video,
    .pai-hero__media img.pai-hero__img {
        width: 100%;
        display: block;
        max-height: 400px;
        object-fit: cover;
    }

    /* ══════════════════════════════════════════════════
       SECTION TITLE (shared)
    ══════════════════════════════════════════════════ */
    .pai-section-header {
        max-width: 1400px;
        margin-inline: auto;
        padding: 0 var(--sp-6) var(--sp-6);
    }
    .pai-section-header__label {
        display: block;
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: var(--color-muted);
        margin-bottom: var(--sp-2);
    }
    .pai-section-header__title {
        font-family: var(--font-heading);
        font-size: clamp(1.8rem, 4vw, 2.8rem);
        font-weight: 900;
        color: var(--color-dark);
        text-transform: uppercase;
        letter-spacing: -0.01em;
        line-height: 1.05;
        padding-bottom: var(--sp-4);
        border-bottom: 3px solid var(--color-dark);
    }

    /* ══════════════════════════════════════════════════
       SECTION 1 — Feature Cards (firstsection)
    ══════════════════════════════════════════════════ */
    .pai-features {
        padding: var(--sp-16) 0;
        background: var(--color-bg);
        border-top: 1px solid var(--color-border);
    }
    .pai-features__grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        max-width: 1400px;
        margin-inline: auto;
        padding-inline: var(--sp-6);
        border-top: 1px solid var(--color-border);
    }
    .pai-feature-card {
        padding: var(--sp-8) var(--sp-6);
        border-right: 1px solid var(--color-border);
        background: var(--color-white);
        display: flex;
        flex-direction: column;
        gap: var(--sp-4);
        transition: background var(--transition);
    }
    .pai-feature-card:last-child { border-right: none; }
    .pai-feature-card:hover { background: #f8f8ff; }
    .pai-feature-card__icon {
        width: 44px;
        height: 44px;
        background: var(--color-primary);
        color: var(--color-white);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: var(--fs-lg);
        border-radius: var(--radius-sm);
        flex-shrink: 0;
    }
    .pai-feature-card__title {
        font-family: var(--font-heading);
        font-size: 1.1rem;
        font-weight: 800;
        text-transform: uppercase;
        color: var(--color-dark);
        line-height: 1.1;
        letter-spacing: -0.01em;
    }
    .pai-feature-card__desc {
        font-size: var(--fs-sm);
        color: var(--color-muted);
        line-height: 1.6;
        flex: 1;
    }
    .pai-feature-card__image {
        width: 100%;
        aspect-ratio: 4/3;
        object-fit: cover;
        display: block;
        filter: grayscale(20%) brightness(0.95);
        margin-top: var(--sp-2);
    }

    /* ══════════════════════════════════════════════════
       SECTION 2 — App Preview (secondsection)
    ══════════════════════════════════════════════════ */
    .pai-preview {
        padding: var(--sp-16) 0;
        background: var(--color-white);
        border-top: 1px solid var(--color-border);
    }
    .pai-preview__inner {
        max-width: 1200px;
        margin-inline: auto;
        padding-inline: var(--sp-6);
    }
    .pai-preview__desc {
        font-size: var(--fs-base);
        color: var(--color-muted);
        text-align: center;
        margin-bottom: var(--sp-6);
        line-height: 1.7;
    }
    .pai-preview__tabs {
        display: flex;
        flex-wrap: wrap;
        gap: var(--sp-2);
        justify-content: center;
        margin-bottom: var(--sp-8);
    }
    .pai-preview__tab {
        display: inline-flex;
        align-items: center;
        gap: var(--sp-2);
        padding: var(--sp-2) var(--sp-5);
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        border: 1.5px solid var(--color-border);
        border-radius: var(--radius-full);
        background: var(--color-white);
        color: var(--color-dark);
        cursor: pointer;
        transition: background var(--transition), color var(--transition), border-color var(--transition);
    }
    .pai-preview__tab:hover,
    .pai-preview__tab.active {
        background: var(--color-dark);
        color: var(--color-white);
        border-color: var(--color-dark);
    }
    .pai-preview__frame {
        border: 1px solid var(--color-border);
        padding: var(--sp-2);
        background: var(--color-bg);
    }
    .pai-preview__frame img {
        width: 100%;
        display: block;
        object-fit: cover;
        max-height:500px;
    }

    /* ══════════════════════════════════════════════════
       SECTION 3 — thirdsection (single featured)
    ══════════════════════════════════════════════════ */
    .pai-spotlight {
        padding: var(--sp-16) 0;
        background: var(--color-bg);
        border-top: 1px solid var(--color-border);
    }
    .pai-spotlight__inner {
        max-width: 900px;
        margin-inline: auto;
        padding-inline: var(--sp-6);
    }
    .pai-spotlight__frame {
        border: 1px solid var(--color-border);
        padding: var(--sp-2);
        background: var(--color-white);
        margin-bottom: var(--sp-6);
    }
    .pai-spotlight__frame img {
        width: 100%;
        display: block;
        object-fit: cover;
    }
    .pai-spotlight__caption {
        font-size: var(--fs-base);
        color: var(--color-muted);
        text-align: center;
        line-height: 1.7;
    }

    /* ══════════════════════════════════════════════════
       SECTION 4 — Testimonials / Power Features
    ══════════════════════════════════════════════════ */
    .pai-testimonials {
        padding: var(--sp-16) 0;
        background: var(--color-white);
        border-top: 1px solid var(--color-border);
    }
    .pai-testimonials__grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: var(--sp-5);
        max-width: 1400px;
        margin-inline: auto;
        padding-inline: var(--sp-6);
        margin-bottom: var(--sp-12);
    }
    .pai-testimonial-card {
        border: 1px solid var(--color-border);
        padding: var(--sp-6);
        background: var(--color-white);
        position: relative;
        transition: box-shadow var(--transition);
    }
    .pai-testimonial-card:hover { box-shadow: var(--shadow-md); }
    .pai-testimonial-card::before {
        content: '\201C';
        position: absolute;
        top: var(--sp-4);
        right: var(--sp-5);
        font-size: 4rem;
        color: var(--color-border);
        font-family: Georgia, serif;
        line-height: 1;
    }
    .pai-testimonial-card__img {
        width: 52px;
        height: 52px;
        border-radius: 50%;
        object-fit: cover;
        filter: grayscale(100%) brightness(0.85);
        margin-bottom: var(--sp-4);
        border: 2px solid var(--color-border);
    }
    .pai-testimonial-card__name {
        font-family: var(--font-heading);
        font-size: var(--fs-base);
        font-weight: 800;
        text-transform: uppercase;
        color: var(--color-dark);
        line-height: 1.1;
        margin-bottom: var(--sp-1);
    }
    .pai-testimonial-card__designation {
        font-size: var(--fs-xs);
        color: var(--color-primary);
        font-family: var(--font-label);
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin-bottom: var(--sp-4);
        display: block;
    }
    .pai-testimonial-card__text {
        font-size: var(--fs-sm);
        color: var(--color-text);
        line-height: 1.65;
    }

    /* CTA Box */
    .pai-cta-box {
        max-width: 860px;
        margin-inline: auto;
        padding-inline: var(--sp-6);
        background: var(--color-dark);
        color: var(--color-white);
        padding: var(--sp-12) var(--sp-10);
        text-align: center;
        position: relative;
        overflow: hidden;
    }
    .pai-cta-box::before {
        content: '';
        position: absolute;
        inset: 0;
        background: repeating-linear-gradient(
            45deg,
            transparent,
            transparent 24px,
            rgba(255,255,255,0.03) 24px,
            rgba(255,255,255,0.03) 25px
        );
        pointer-events: none;
    }
    .pai-cta-box__title {
        font-family: var(--font-heading);
        font-size: clamp(1.6rem, 4vw, 2.4rem);
        font-weight: 900;
        text-transform: uppercase;
        color: var(--color-white);
        line-height: 1.05;
        margin-bottom: var(--sp-4);
        position: relative;
    }
    .pai-cta-box__text {
        font-size: var(--fs-base);
        color: rgba(255,255,255,0.65);
        line-height: 1.7;
        margin-bottom: var(--sp-8);
        max-width: 560px;
        margin-inline: auto;
        position: relative;
    }
    .pai-cta-box__text strong { color: var(--color-white); }
    .pai-cta-box__btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: var(--sp-4) var(--sp-10);
        background: var(--color-primary);
        color: var(--color-white);
        font-family: var(--font-label);
        font-size: var(--fs-xs);
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        border: 2px solid var(--color-primary);
        border-radius: var(--radius-sm);
        cursor: pointer;
        position: relative;
        transition: background var(--transition), transform var(--transition);
    }
    .pai-cta-box__btn:hover {
        background: var(--color-primary-dark);
        border-color: var(--color-primary-dark);
        transform: translateY(-2px);
    }

    /* ══════════════════════════════════════════════════
       NEWS LAYOUT SECTION (design version)
    ══════════════════════════════════════════════════ */
    .pai-news-wrap {
        padding-top: var(--sp-16);
        border-top: 1px solid var(--color-border);
    }

    /* ══════════════════════════════════════════════════
       RESPONSIVE
    ══════════════════════════════════════════════════ */
    @media (max-width: 1024px) {
        .pai-features__grid { grid-template-columns: repeat(3, 1fr); }
        .pai-testimonials__grid { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 768px) {
        .pai-features__grid {
            grid-template-columns: 1fr;
            border-top: none;
        }
        .pai-feature-card {
            border-right: none;
            border-bottom: 1px solid var(--color-border);
        }
        .pai-feature-card:last-child { border-bottom: none; }
        .pai-testimonials__grid { grid-template-columns: 1fr; }
        .pai-hero { padding: var(--sp-10) var(--sp-4) var(--sp-8); }
        .pai-cta-box { padding: var(--sp-8) var(--sp-5); }
    }
    @media (max-width: 480px) {
        .pai-preview__tabs { gap: var(--sp-1); }
        .pai-preview__tab { font-size: 0.6rem; padding: var(--sp-1) var(--sp-3); }
    }
</style>
<div class="news-layout">

    <!-- ── LEFT SIDEBAR ── -->
    <aside class="sidebar-left" aria-label="Latest News">
      <h2 class="sidebar__section-title">NEUESTE NACHRICHTEN</h2>
      @foreach($latestPosts as $post)
      <!-- Article 1 -->
      <article class="sidebar-article">
        <img
          src="{{ asset($post->thumb) }}"
          alt="Skill Gap 2026"
          class="sidebar-article__image"
          loading="lazy"
        />
        <div class="sidebar-article__category">  {{ $post->parent_data->name ?? 'General' }}</div>
        <h3 class="sidebar-article__title" onclick="window.location='{{ route('forum.topic.web', $post->slug) }}'">      {{ $post->title }}</h3>
        <p class="sidebar-article__excerpt">      {!! Str::limit($post->short_desc, 80) !!}</p>
        <div class="sidebar-article__date">       {{ \Carbon\Carbon::parse($post->date)->format('F d, Y') }}</div>
      </article>
@endforeach
    </aside>

    <!-- ── CENTER: MAIN ARTICLE ── -->
    <section class="main-article" aria-label="Featured Article">

      <!-- Hero Image with label -->
      <div class="main-article__image-wrapper">
        <img
          src="{{ asset($featuredPost->thumb) }}"
          alt="Students in a classroom"
          class="main-article__hero-image"
          loading="eager"
        />
        <div class="main-article__image-tag">
          <span class="label-tag">   {{ $featuredPost->parent_data->name ?? 'Featured' }}</span>
        </div>
      </div>

      <!-- Article content -->
      <h1 class="main-article__title">   {{ $featuredPost->title }}</h1>
      <p class="main-article__excerpt">
        {{ Str::limit($featuredPost->short_desc, 150) }}
      </p>

      <div class="main-article__meta">
        <span>{{ \Carbon\Carbon::parse($featuredPost->date)->format('F d, Y') }}</span>
        <span class="separator">•</span>
        <span>{{ $featuredPost->views }} Read</span>
        <a href="{{ route('forum.topic.web', $post->slug) }}"  class="read-more-link" style="color: var(--color-primary); font-weight:700; margin-left: auto;">
          Read More &rsaquo;
        </a>
      </div>
    </section>

    <!-- ── RIGHT SIDEBAR ── -->
    <aside class="sidebar-right" aria-label="Promotions and Most Read">

      <!-- Promo Box -->
      <div class="promo-box">
        <h2 class="promo-box__title">Upgrade Your Future</h2>
        <p class="promo-box__subtitle">Sichere dir exklusive Branchen-Insights und 1-zu-1 Mentoring.</p>
        <a href="{{ route('premium') }}" class="btn btn-outline-white">JETZT BEITRETEN</a>
      </div>

      <!-- Most Read -->
      <div class="most-read">
        <h3 class="most-read__title">MEISTGELESEN</h3>
        @foreach($mostReadPosts as $index => $post)
        <div class="most-read__item">
          <div class="most-read__item-number">{{ str_pad($index+1, 2, '0', STR_PAD_LEFT) }}</div>
          <div class="most-read__item-info">
            <div class="most-read__item-category">         {{ $post->parent_data->name ?? 'General' }}</div>
            <div class="most-read__item-title" onclick="window.location='{{ route('forum.topic.web', $post->slug) }}'">     {{ $post->title }}</div>
          </div>
          <img
            src="{{ asset($post->thumb) }}"
            alt="{{ asset($post->title) }}"
            class="most-read__item-image"
            loading="lazy"
          />
        </div>
        @endforeach


      </div>

    </aside>
  </div><!-- /.news-layout -->
{{-- ══════════════════════════════════════════════════
     HERO SECTION
══════════════════════════════════════════════════ --}}


{{-- ══════════════════════════════════════════════════
     SECTION 1 — Was ProAISkill dir schenkt (firstsection)
══════════════════════════════════════════════════ --}}

{{-- ══════════════════════════════════════════════════
     SECTION 2 — App Preview (secondsection) #funktionenSection
══════════════════════════════════════════════════ --}}


{{-- ══════════════════════════════════════════════════
     SECTION 3 — Spotlight / thirdsection
══════════════════════════════════════════════════ --}}

{{-- ══════════════════════════════════════════════════
     SECTION 4 — Power Features / Testimonials (section-4)
══════════════════════════════════════════════════ --}}


    <!-- ════════════════════════════════════════
         JOB RADAR SECTION
    ════════════════════════════════════════ -->
    <section class="job-radar" id="job-offers" aria-label="Job Radar">
        <div class="job-radar__header">
          <div class="job-radar__left">
            <span class="label-tag">Career Intelligence</span>
            <h2 class="job-radar__title">Job Radar</h2>
            <p class="job-radar__subtitle">Exclusive Entry Opportunities for Members</p>
          </div>
          <a href="{{ route('career.web')   }}" class="btn btn-outline">
            View All Vacancies &nbsp;&rsaquo;
          </a>
        </div>
  
        <!-- Job Cards -->
        <div class="job-cards-grid">
  @foreach ($jobs as $j )
            <!-- Card 1 -->
            <article class="job-card" role="article">
                <div class="job-card__category">{{ $j->job_type }}</div>
                <h3 class="job-card__title">{{ $j->name }}</h3>
                <div class="job-card__company">{{ $j->company_name }}</div>
                <div class="mt-2">
                    <span class="d-flex justify-content-normal align-items-center gap-2">
                        <i data-lucide="map-pin" height="15" width="15"></i>
                       {{ $j->company_location }}
                    </span>
                </div>
              </article>
  @endforeach
    

  
        </div>
      </section>


    <!-- ════════════════════════════════════════
         MARKETPLACE HERO SECTION
    ════════════════════════════════════════ -->
    <section class="marketplace-hero" id="marketplace" aria-label="Marketplace">
        <div class="marketplace-hero__inner">
  
          <!-- Left: Text -->
          <div class="marketplace-hero__content">
            <span class="marketplace-hero__label">Marketplace</span>
            <h2 class="marketplace-hero__title">Spare im Studium, investiere in deine Skills.</h2>
            <p class="marketplace-hero__text">
                Wir haben mit über 100 Partnern verhandelt, um dir exklusive Deals für Hardware, Software und Lifestyle zu sichern.
            </p>
            <a href="#" class="btn btn-primary">ALLE DEALS ENTDECKEN</a>
          </div>
  
          <!-- Right: Image -->
          <div class="marketplace-hero__image-wrapper">
            <img
              src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800&q=75"
              alt="Students walking on campus"
              class="marketplace-hero__image"
              loading="lazy"
            />
          </div>
  
        </div>
      </section>
    {{-- CTA Box --}}

</section>

{{-- ══════════════════════════════════════════════════
     NEWS + JOB RADAR + MARKETPLACE  (design system sections)
══════════════════════════════════════════════════ --}}


{{-- ══════════════════════════════════════════════════
     FRONTEND FOOTER (original logic preserved)
══════════════════════════════════════════════════ --}}
{{-- {!! get_setting('frontend_footer') !!} --}}

@endsection

@section('home_style')
    <link rel="stylesheet" href="{{ asset('new_asset/style/style.css') }}">
@endsection